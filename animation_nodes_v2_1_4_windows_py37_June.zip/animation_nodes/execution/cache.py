from .. utils import fcurve

def clearExecutionCache():
    fcurve.clearCache()
