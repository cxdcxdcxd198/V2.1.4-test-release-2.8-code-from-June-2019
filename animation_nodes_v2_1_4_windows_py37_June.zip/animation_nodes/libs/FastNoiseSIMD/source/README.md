This is the FastNoiseSIMD library (with minor modifications) developed by Jordan Peck.

The main repository of it can be found here: https://github.com/Auburns/FastNoiseSIMD
